<?php if (is_active_sidebar('entr-right-sidebar')) { ?>
    <aside id="sidebar" class="col-md-4">
        <?php dynamic_sidebar('entr-right-sidebar'); ?>
    </aside>
<?php 
}
